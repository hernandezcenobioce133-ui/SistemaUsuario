/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.automatonsimulador;

/**
 *
 * @author Camii
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class AutomatonSimulador extends JFrame {

    private JTextField txtVariable;
    private JComboBox<String> cmbModo;
    private JTextArea txtResultado;
    private JLabel lblEmoji;

    public AutomatonSimulador() {
        setTitle("Simulador Inteligente de Autómatas");
        setSize(750, 570);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Colores solicitados
        Color colorMoradoTop = new Color(0xaa, 0x8c, 0xaf);
        Color colorBarraInput = new Color(0xe2, 0xd8, 0xe4);
        Color colorBlanco = Color.WHITE;

        // --- DISEÑO SUPERIOR ---
        JPanel panelTop = new JPanel();
        panelTop.setBackground(colorMoradoTop);
        panelTop.setBorder(new EmptyBorder(20, 20, 20, 20));
        panelTop.setLayout(new GridLayout(2, 1, 5, 5));

        JLabel lblTitulo = new JLabel("✨ SIMULADOR DE AUTOMATAS ✨", JLabel.CENTER);
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));

        JLabel lblSub = new JLabel("Escribe una variable o palabra y comprueba cómo la procesa el autómata.", JLabel.CENTER);
        lblSub.setForeground(new Color(245, 245, 245));
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 13));

        panelTop.add(lblTitulo);
        panelTop.add(lblSub);
        add(panelTop, BorderLayout.NORTH);

        // --- DISEÑO CENTRAL (FONDO BLANCO) ---
        JPanel panelCentro = new JPanel();
        panelCentro.setBorder(new EmptyBorder(20, 30, 10, 30));
        panelCentro.setLayout(new GridLayout(5, 1, 8, 8));
        panelCentro.setBackground(colorBlanco);

        JLabel lblSelector = new JLabel("Selecciona el tipo de regla (Autómata):");
        lblSelector.setFont(new Font("SansSerif", Font.BOLD, 13));
        
        cmbModo = new JComboBox<>(new String[]{
            "1. Validador de Variable (Inicia con letra, luego letras o números)",
            "2. Detector de Secuencia (Palabras que terminan en 'b')",
            "3. Autómata No Determinista (AFND - Ejemplo a(b|c)*)",
            "4. Demostración de Minimización de Estados",
            "5. Caso de Estudio: Identificador de Código Válido"
        });
        cmbModo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        cmbModo.setBackground(colorBarraInput); // Color e2d8e4

        JLabel lblInput = new JLabel("Escribe la variable o texto a simular:");
        lblInput.setFont(new Font("SansSerif", Font.BOLD, 13));

        txtVariable = new JTextField("miVariable123");
        txtVariable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtVariable.setBackground(colorBarraInput); // Color e2d8e4
        txtVariable.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        // Contenedor para mostrar la carita feliz o triste
        JPanel panelEmojiContainer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelEmojiContainer.setBackground(colorBlanco);
        JLabel lblTextoEstado = new JLabel("Resultado visual: ");
        lblTextoEstado.setFont(new Font("SansSerif", Font.BOLD, 13));
        
        lblEmoji = new JLabel("😐");
        lblEmoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        
        panelEmojiContainer.add(lblTextoEstado);
        panelEmojiContainer.add(lblEmoji);

        panelCentro.add(lblSelector);
        panelCentro.add(cmbModo);
        panelCentro.add(lblInput);
        panelCentro.add(txtVariable);
        panelCentro.add(panelEmojiContainer);

        add(panelCentro, BorderLayout.CENTER);

        // --- BOTÓN Y RESULTADOS (FONDO BLANCO) ---
        JPanel panelSur = new JPanel();
        panelSur.setBorder(new EmptyBorder(10, 30, 20, 30));
        panelSur.setLayout(new BorderLayout(10, 10));
        panelSur.setBackground(colorBlanco);

        JButton btnSimular = new JButton("SIMULAR VARIABLE");
        btnSimular.setBackground(colorMoradoTop); // Color aa8caf
        btnSimular.setForeground(Color.BLACK);    // Letra negra
        btnSimular.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnSimular.setFocusPainted(false);
        btnSimular.setCursor(new Cursor(Cursor.HAND_CURSOR));

        txtResultado = new JTextArea(5, 20);
        txtResultado.setEditable(false);
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtResultado.setBackground(new Color(250, 250, 250));
        txtResultado.setBorder(BorderFactory.createLineBorder(new Color(220, 221, 225)));
        JScrollPane scrollPane = new JScrollPane(txtResultado);

        btnSimular.addActionListener(e -> ejecutarSimulacion());

        panelSur.add(btnSimular, BorderLayout.NORTH);
        panelSur.add(scrollPane, BorderLayout.CENTER);

        add(panelSur, BorderLayout.SOUTH);
    }

    private void ejecutarSimulacion() {
        String texto = txtVariable.getText().trim();
        int seleccion = cmbModo.getSelectedIndex();
        StringBuilder resultado = new StringBuilder();

        if (texto.isEmpty()) {
            txtResultado.setText("⚠️ Por favor, escribe una variable o texto válido para simular.");
            lblEmoji.setText("😐");
            return;
        }

        boolean aceptado = false;
        resultado.append("🔍 Analizando el texto: [ ").append(texto).append(" ]\n");
        resultado.append("--------------------------------------------------\n");

        switch (seleccion) {
            case 0:
                aceptado = validarVariable(texto);
                resultado.append("• Regla: Debe iniciar con letra y contener solo letras o números.\n");
                break;
            case 1:
                aceptado = texto.endsWith("b");
                resultado.append("• Regla: La secuencia debe terminar obligatoriamente con la letra 'b'.\n");
                break;
            case 2:
                aceptado = texto.matches("^a[bc]*$");
                resultado.append("• Regla AFND (Thompson): Inicia con 'a' y se repite 'b' o 'c'.\n");
                break;
            case 3:
                aceptado = validarVariable(texto);
                resultado.append("• Proceso de Minimización de Estados:\n");
                resultado.append("  - Estados originales: 5 ➔ Optimizados a 3 esenciales.\n");
                break;
            case 4:
                aceptado = texto.matches("^[a-zA-Z_][a-zA-Z0-9_]*$");
                resultado.append("• Aplicación en Compiladores (Identificador Válido).\n");
                break;
        }

        if (aceptado) {
            lblEmoji.setText("😊"); // Carita feliz si es aceptado
            resultado.append("✅ RESULTADO: ¡VARIABLE ACEPTADA!");
        } else {
            lblEmoji.setText("😢"); // Carita triste si es denegado
            resultado.append("❌ RESULTADO: VARIABLE DENEGADA / RECHAZADA.");
        }

        txtResultado.setText(resultado.toString());
    }

    private boolean validarVariable(String str) {
        if (str == null || str.length() == 0) return false;
        char primero = str.charAt(0);
        if (!Character.isLetter(primero)) return false;
        for (int i = 1; i < str.length(); i++) {
            char c = str.charAt(i);
            if (!Character.isLetterOrDigit(c)) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            new AutomatonSimulador().setVisible(true);
        });
    }
}