/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemausuario;

/**
 *
 * @author Camii
 */
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SistemaUsuario {

    public static void main(String[] args) {
        // Inicializamos el objeto Scanner para leer la entrada de datos por teclado del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.println("SISTEMA DE REGISTRO Y LOGIN");

        /* 
         * DEFINICIÓN DE LAS 3 EXPRESIONES REGULARES (ER)
         * 1. ER para el Usuario: Solo letras (mayúsculas o minúsculas), números o guion bajo. Longitud entre 5 y 15.
         * 2. ER para la Contraseña: Mínimo 8 caracteres, al menos 1 número, 1 letra mayúscula y 1 carácter especial.
         * 3. ER para el Correo: Formato estándar de email (texto + @ + dominio + .com/.mx, etc.).
         */
        String regexUsuario = "^[a-zA-Z0-9_]{5,15}$";
        String regexPassword = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{8,}$";
        String regexCorreo = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";

        // Compilamos las cadenas de las expresiones regulares en objetos Pattern para optimizar su evaluación en Java
        Pattern patternUsuario = Pattern.compile(regexUsuario);
        Pattern patternPassword = Pattern.compile(regexPassword);
        Pattern patternCorreo = Pattern.compile(regexCorreo);

        boolean loginExitoso = false;

        // Bucle while para obligar al usuario a ingresar datos válidos para el Login/Registro
        while (!loginExitoso) {
            System.out.println("Ingrese un nuevo nombre de usuario (5-15 caracteres alfanuméricos):");
            String inputUsuario = scanner.nextLine(); // Leemos la cadena ingresada por teclado

            System.out.println("Ingrese una nueva contraseña (min 8 caracteres, 1 mayúscula, 1 número, 1 carácter especial):");
            String inputPassword = scanner.nextLine(); // Leemos la contraseña

            // Creamos los objetos Matcher, que se encargan de comparar las cadenas del usuario contra nuestros Patrones (ER)
            Matcher matcherUsuario = patternUsuario.matcher(inputUsuario);
            Matcher matcherPassword = patternPassword.matcher(inputPassword);

            // Verificamos si ambas cadenas ingresadas cumplen exactamente con las reglas de sus respectivas ER
            if (matcherUsuario.matches() && matcherPassword.matches()) {
                System.out.println("¡Login exitoso! Bienvenido al sistema, " + inputUsuario + ".");
                loginExitoso = true; // Cambiamos la bandera a true para romper el bucle y avanzar
            } else {
                System.out.println("[ERROR] Datos de login inválidos. Revise los requisitos:");
                // Validaciones individuales para darle retroalimentación específica al usuario
                if (!matcherUsuario.matches()) {
                    System.out.println("- El usuario tiene un formato incorrecto.");
                }
                if (!matcherPassword.matches()) {
                    System.out.println("- La contraseña es muy débil o no cumple los requisitos.");
                }
            }
        }

        // Una vez que el login es exitoso, pasamos a la tercera ER para completar el perfil
        boolean correoValido = false;
        
        while (!correoValido) {
            System.out.println("Para completar su perfil, ingrese un correo electrónico de recuperación:");
            String inputCorreo = scanner.nextLine(); // Leemos la tercera cadena de texto

            // Evaluamos la cadena del correo electrónico con su respectivo Matcher
            Matcher matcherCorreo = patternCorreo.matcher(inputCorreo);

            // Condicional que verifica si el correo cumple con el formato estándar
            if (matcherCorreo.matches()) {
                System.out.println("¡Correo aceptado! Perfil actualizado con éxito.");
                correoValido = true; // Rompemos el bucle del correo
            } else {
                System.out.println("[ERROR] Formato de correo inválido. Ejemplo aceptado: usuario@dominio.com");
            }
        }

        System.out.println("Operación finalizada. Cerrando sistema...");
        
        // Cerramos el flujo del scanner por buenas prácticas de programación para evitar fugas de memoria
        scanner.close();
    }
}